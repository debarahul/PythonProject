rm -rf result.csv
rm -rf nohup.out
rm -rf report-maxdocs.xlsx
python3 nfdbauto.py
